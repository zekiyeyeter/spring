package com.spring.spring.Controllers;

public class LikeController {
}
